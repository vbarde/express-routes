var http = require("http");
var path=require("path");
// var { requestHandler } = require("./request-handler");
const app = require("./server");

//var server = http.createServer(requestHandler);
var server = http.createServer(app);
server.listen(5000, (err) => {
    if (err) {
        console.log("couldnt load server");
        return;
    }
    console.log("Server started in port 5000");
})