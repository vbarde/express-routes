var path=require("path");
const express = require("express");
const bodyParser = require("body-parser");
const cookieParser = require("cookie-parser");
const session = require("express-session");

//create express app object
var app = express();

//configure application middleware
app.use(express.static(path.resolve(__dirname,"public")));

app.use((req, res, next) => {
    req.author = "VISHAL";
    req.verified = true;
    next();
});
app.use(cookieParser("mysecretkey"));
app.use(session({ name: "session", resave: true, saveUninitialized: false, secret: "mysecretsessionkey" }));
//resave-used for configuration ,changes made doesnt affect
//saveUninitialized-do not initialize session

//configure request handlers
app.get("/", homeMiddleware, (req, res) => {
    res.cookie("company", "Capgemini", { maxAge: 60000, signed: true });//httpOnly:true =create cookies only for http AND also use expires:new Date(2018,12,31)  
    res.cookie("place", "Pune");

    req.session.Department = "Consulting";
    req.session.Salary = 9000;

    res.header("Content-Type", "text/html").send(`<link rel="stylesheet" href="./mystyles.css"><h2>HOME PAGE</h2>` + req.message);
});
app.get("/about", (req, res) => {
    var companyName = req.signedCookies.company || "NIL";
    var placeName = req.cookies.place || "NIL";
    var dept = req.session.Department || "NIL";
    var salary = req.session.Salary || 0;
    // res.clearCookie("company");
    // res.clearCookie("place");
    req.session.destroy();
    res.header("Content-Type", "text/html").send(`<h2>ABOUT PAGE</h2><p>Details:${companyName}---${placeName}--${dept}--${salary}</p>`);
});
app.get("/contact", (req, res) => {
    res.header("Content-Type", "text/html").send("<h2>CONTACT PAGE</h2>" + req.verified);
});

module.exports = app;

//another way to apply middleware
function homeMiddleware(req, res, next) {
    req.message = "HELLO HELLO";
    next();
}