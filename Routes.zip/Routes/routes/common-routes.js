
const express = require("express");

var router=express.Router();
router.get("/", (req, res) => {
    res.header("Content-Type", "text/html").render("index");
});
router.get("/about", (req, res) => {
    res.header("Content-Type", "text/html").render("about");
});
router.get("/contact", (req, res) => {
    res.header("Content-Type", "text/html").render("CONTACT");
});
// router.get("/register", (req, res) => {
//     res.header("Content-Type", "text/html").render("register");
// });

module.exports = router;