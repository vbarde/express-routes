// exports.requestHandler=(req, res) => {
//     //Write the code to handle request
//     res.setHeader("Content-Type", "text/html");
//     if (req.url == "/") {
//         res.write("<h2>Hello,Welcome to node server</h2>");
//     } else if (req.url == "/about") {
//         res.write("<h2>About page</h2>");
//     } else if (req.url == "/contact") {
//         res.write("<h2>Contact page</h2>");
//     }
//     res.end();
// }
var path = require("path");
var fs = require("fs");

exports.requestHandler = (req, res) => {
    //Write the code to handle request
    res.setHeader("Content-Type", "text/html");
    var layout = getViewContent("layout.html");
    if (req.url == "/") {
        
        var body = getViewContent("index.html");
        var content=layout.replace("{{body-content}}",body);
        res.write(content);
        res.end();
    } else if (req.url == "/about") {
        var body = getViewContent("about.html");
        var content=layout.replace("{{body-content}}",body);
        res.write(content);
        res.end();
    } else if (req.url == "/contact") {
        var body = getViewContent("contact.html");
        var content=layout.replace("{{body-content}}",body);
        res.write(content);
        res.end();
    }else if(req.url=="/register" && req.method=="GET"){
        var body = getViewContent("register.html");
        var content=layout.replace("{{body-content}}",body);
        res.write(content);
        res.end();
    }else if(req.url=="/register" && req.method=="POST"){
        var formData="";
        req.on("data",(chunk)=>{
            formData+=chunk;
        });
        req.on("end",()=>{
            res.write(formData);
            res.end();
        })
    }
}
function getViewContent(filename) {
    var filePath = path.resolve(__dirname, "Views", filename);
    var content = fs.readFileSync(filePath);
    return content.toString();
}